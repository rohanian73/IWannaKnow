package com.example.demo.security;

import java.io.IOException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.GenericFilterBean;

import com.example.demo.model.User;
import com.example.demo.service.UserService;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class JWTAuthenticationFilter extends GenericFilterBean {
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {

		HttpServletRequest req = (HttpServletRequest) request;
		
		String reqUrl = req.getRequestURL().toString();
		String reqQuery = req.getQueryString();
		
		System.out.println("PathInfo: " + reqUrl);
		System.out.println("QueryString: " + reqQuery);

		if (reqUrl.contains("forgotPassword")) {
			
			HttpServletResponse res = (HttpServletResponse) response;
			res.addHeader("Token-Type", "reset");
			
			String username = reqQuery.substring(6); // skipping 'email='
			System.out.println(username);
			
			JWTService.addToken(req, res, username);
		}
		
		else if (reqUrl.contains("resetPassword")) {

			HttpServletResponse res = (HttpServletResponse) response;
			String username = req.getHeader("Username");
			JWTService.verifyToken(username, req, res);
			
		}
		
		else {
			Authentication authentication = JWTService.getAuthentication((HttpServletRequest)request);

			SecurityContextHolder.getContext().
			setAuthentication(authentication);
			filterChain.doFilter(request, response);
		}


	}
}
