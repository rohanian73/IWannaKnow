package com.example.demo.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.UserPostDTO;
import com.example.demo.model.User;
import com.example.demo.security.LoginFilter;
import com.example.demo.service.UserService;


@RestController
@CrossOrigin("http://localhost:3000")
public class UserController {
	
	@Autowired
	UserService userService;


	// Get All Users
    @GetMapping("/user")
    public List<User> getUsers() {
        return userService.getUsers();
    }
    
    // Social Login
    @PostMapping("/user")
    public ResponseEntity<Optional<User>> addUser(@RequestBody UserPostDTO newUserDTO) {
    		
    	User user = userService.findByEmail(newUserDTO.getEmail());

    	System.out.println(user);

    	if (user == null) {
    		
    		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
    		
    		User newUser = new User(newUserDTO.getEmail(), newUserDTO.getFirstname(), newUserDTO.getLastname(), 
    				encoder.encode("null"));
    		userService.addUser(newUser);
    		return new ResponseEntity<>(Optional.ofNullable(newUser),HttpStatus.CREATED);
    		
    	} else {
    		return new ResponseEntity<>(HttpStatus.OK);
    	}
    	
    }
    
    // Get User by ID
    @PostMapping("/user/{id}")
    public Optional<User> getUserById(@PathVariable(value = "id") long Id) {
    	Optional<User> user = userService.findByID(Id);
    	return user;
    }
    
    
    //Delete a User by ID
    @DeleteMapping("/user/{id}")
    public String deleteUser(@PathVariable(value = "id") long Id) {
        userService.deleteUser(Id);
        return "User Deleted"; 
    }
    
    //Get User by Email
    @PostMapping("/user/findByEmail")
    public String getUserByEmail(@RequestParam String email) {
    	
    	User user = userService.findByEmail(email);
    	
    	if (user == null) {
    		return "Not found";
    	}
    	
    	return "Found";
    	
    }
    
    //Get ID by Email
    @PostMapping("/user/findIdByEmail")
    public Long getIdByEmail(@RequestParam String email) {
    	
    	User user = userService.findByEmail(email);
    	
    	return user.getId();
    	
    }
    
    // Forgot Password
    @GetMapping("/user/forgotPassword")
    public String getRecoveryLink(@RequestParam String email) {
    	
    	return "Hello Forgot Password";
    	
    }
    
    
    // Verify Password-Reset Token
    @GetMapping("/user/resetPassword/{id}/{token}")
    public String verifyPasswordResetToken(@PathVariable String id, @PathVariable String token) {
    	
    	return "Hello Forgot Password / ID / Token";
    	
    }
    
    // Change Password
    @PostMapping("/user/changePassword")
    public String setPassword(@RequestParam String email, @RequestParam String password) {
    	
    	System.out.println(email + " " + password);
    	
    	BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
    	
    	User user = userService.findByEmail(email);
    	
    	try {
        	user.setPassword(encoder.encode(password));
        	userService.addUser(user);
        	return "Password is changed";
        			
    	} catch(Exception e) {
    		return e.getMessage();
    	}
    	
    }
    
    
}
