package com.example.demo.security;

import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;

import javax.crypto.SecretKey;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class JWTService {

	  static final String SIGNINGKEY = "9a4f2c8d3b7a1e6f45c8a0b3f267d8b1d4e6f3c8a9d2b5f8e3a9c8b5f6v8a3d9";
	  static final String PREFIX = "Bearer";
	  
	  // Add token to Authorization header
	  static public void addToken(HttpServletRequest req, HttpServletResponse res, String username) {
		
		String tokenType = res.getHeader("Token-Type");
		
		// Reset Token
		if (tokenType == "reset") {
			
			final long PASSWORD_RECOVERY_TIME = 900000; // 15 minutes in ms
			
			SecretKey key = Keys.hmacShaKeyFor(SIGNINGKEY.getBytes());
			String JwtToken = Jwts.builder()
					.subject(username)
					.expiration(new Date(System.currentTimeMillis() 
							+ PASSWORD_RECOVERY_TIME))
					.signWith(key)
					.compact();
			
			System.out.println(JwtToken);
			System.out.println("ExpTime: " + new Date(System.currentTimeMillis() + PASSWORD_RECOVERY_TIME));
			System.out.println(System.currentTimeMillis() + PASSWORD_RECOVERY_TIME);
			
			res.addHeader("Password_Recovery_Token", JwtToken);
			res.addHeader("Access-Control-Expose-Headers", "Password_Recovery_Token");
			
		} 
		
		// Login Token
		else {
			
			String rememberMe = req.getHeader("rememberMe");
			System.out.println(rememberMe);
			long EXPIRATIONTIME;
			
			if (rememberMe.equals("true")) {
				EXPIRATIONTIME = 864_000_00; // 1 day in ms
			} else {
				EXPIRATIONTIME = 7200000; // 2 hours in ms
			}
			
			SecretKey key = Keys.hmacShaKeyFor(SIGNINGKEY.getBytes());
			String JwtToken = Jwts.builder()
					.subject(username)
					.expiration(new Date(System.currentTimeMillis() 
							+ EXPIRATIONTIME))
					.signWith(key)
					.compact();
			System.out.println(JwtToken);
			System.out.println("ExpTime: " + new Date(System.currentTimeMillis() + EXPIRATIONTIME));
			System.out.println(System.currentTimeMillis() + EXPIRATIONTIME);
			
			res.addHeader("Authorization", PREFIX + " " + JwtToken);
			res.addHeader("Access-Control-Expose-Headers", "Authorization");
		}
	    
	  }
	  
	  // Add unsuccessful token
	  static public void addUnsuccessfulToken(HttpServletResponse res, String ex) {
		  
		  System.out.println(ex);
		  res.addHeader("Authorization", ex);
		  res.addHeader("Access-Control-Expose-Headers", "Authorization");
		  
	  }
	  
	  // Verify Token
	  static public void verifyToken(String username, HttpServletRequest req, HttpServletResponse res) {
		  
		  System.out.println("verifyToken");
		  
		  boolean tokenValidity = false;
		  
		  String reqUrl = req.getRequestURL().toString();
		  String [] reqArr = reqUrl.split("/");

		  String token = reqArr[reqArr.length - 1];
		  String [] tokenArr = token.split("\\.");

		  try {

			  Base64.Decoder decoder = Base64.getUrlDecoder();
//			  String header = new String(decoder.decode(tokenArr[0]));
			  String payload = new String(decoder.decode(tokenArr[1]));

			  System.out.println(payload);

			  String testUsername = payload.split("\"")[3];
			  System.out.println(testUsername);

			  String expTimeString = payload.split("\"")[6];
			  expTimeString = expTimeString.substring(1, expTimeString.length() - 1);
			  Long expTime = (long) Integer.parseInt(expTimeString);
			  expTime *= 1000;
			  System.out.println(expTime);

			  // Check Username
			  if (testUsername.equals(username)) {

				  long currentTime = System.currentTimeMillis();
				  
				  System.out.println("Current time: " + new Date(currentTime));
				  System.out.println("Expiration time: " + new Date(expTime));

				  // Check Expiration Time
				  if (expTime > currentTime) {
					  
					  // Check Signature
					  SecretKey key = Keys.hmacShaKeyFor(SIGNINGKEY.getBytes());
					  
					  try {
						  String user = Jwts.parser()
								  .verifyWith(key)
								  .build()
								  .parseSignedClaims(token)
								  .getPayload()
								  .getSubject();
						  
						  if (user != null) {
							  tokenValidity = true;
						  }

					  } catch(Exception e){
						  System.out.println("Invalid Token (signature)");
					  }
					  
				  } else {
					  System.out.println("Invalid Token (expired)");
				  }

			  } else {
				  System.out.println("Invalid Token (username)");
			  }

		  } catch(Exception e) {
			  System.out.println("Invalid Token (exception)");
		  }


		  if (tokenValidity == true) {
			  System.out.println("Token is valid");
			  res.addHeader("Token_Validity", "Valid Token");
			  res.addHeader("Access-Control-Expose-Headers", "Token_Validity");
		  } else {
			  res.addHeader("Token_Validity", "Invalid Token");
			  res.addHeader("Access-Control-Expose-Headers", "Token_Validity");
		  }
		  
	  }

	  // Get token from Authorization header
	  static public Authentication getAuthentication(HttpServletRequest request) {

		  System.out.println("getAuthentication");


		  String token = request.getHeader("Authorization");
		  SecretKey key = Keys.hmacShaKeyFor(SIGNINGKEY.getBytes());

		  if (token != null) {
			  try {
				  String user = Jwts.parser()
						  .verifyWith(key)
						  .build()
						  .parseSignedClaims(token.replace("Bearer ", ""))
						  .getPayload()
						  .getSubject();
				  if (user != null) 
					  return new UsernamePasswordAuthenticationToken(user, null, new ArrayList<>()); 
			  }catch(Exception e){
				  System.out.println(e.getMessage());
			  }
		  }



		  return null;
		  
		  
	  }
	}