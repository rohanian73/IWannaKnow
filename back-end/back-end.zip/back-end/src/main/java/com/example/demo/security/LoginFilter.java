package com.example.demo.security;

import java.io.IOException;
import java.io.ObjectInputFilter.Config;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import com.example.demo.service.UserService;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

public class LoginFilter extends AbstractAuthenticationProcessingFilter {
	  
	  AccountCredentials creds;
	
	  public LoginFilter(String url, AuthenticationManager authManager) {
		super(new AntPathRequestMatcher(url));
	    this.setAuthenticationManager(authManager);
	  }

	@Override
	  public Authentication attemptAuthentication(
	  HttpServletRequest req, HttpServletResponse res)
	      throws AuthenticationException, IOException, ServletException {
		
	  creds = new ObjectMapper()
	        .readValue(req.getInputStream(), AccountCredentials.class);
	  
	  return this.getAuthenticationManager().authenticate(
	        new UsernamePasswordAuthenticationToken(
	            creds.getUsername(),
	            creds.getPassword()
	        )
	    );
	  }

	  @Override
	  protected void successfulAuthentication(
	      HttpServletRequest req,
	      HttpServletResponse res, FilterChain chain,
	      Authentication auth) throws IOException, ServletException {
		  JWTService.addToken(req, res, auth.getName());
	  }
	  
	  @Override
	  protected void unsuccessfulAuthentication(
		  HttpServletRequest req,
		  HttpServletResponse res,
		  AuthenticationException ex) throws IOException, ServletException {
		  
		  System.out.println(creds.getUsername() + " " + creds.getPassword());
		  JWTService.addUnsuccessfulToken(res, ex.getMessage());
	  }
	  
	}